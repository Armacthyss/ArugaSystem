using Microsoft.AspNetCore.Mvc;
using VaccineWebAPI.Data;
using VaccineWebAPI.Models;

namespace VaccineWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VaccinationController : ControllerBase
    {
        private readonly VaccinationRepository _repository;

        public VaccinationController(VaccinationRepository repository)
        {
            _repository = repository;
        }

        // ==========================================
        // PARENT / GUARDIAN
        // ==========================================

        // ✅ MATCH VUE: /GetAllParents
        [HttpGet("GetAllParents")]
        public IActionResult GetAllParents()
        {
            var parents = _repository.GetAllParents();
            return Ok(parents);
        }

        [HttpPost("SaveParent")]
        public IActionResult SaveParent([FromBody] Parent parent)
        {
            if (parent == null)
                return BadRequest(new { success = false, message = "Invalid data." });

            try
            {
                bool isNew = parent.ParentID == Guid.Empty;

                bool result = _repository.SaveParent(parent);

                if (!result)
                    return StatusCode(500, new { success = false, message = "Database insert failed." });

                return Ok(new
                {
                    success = true,
                    message = isNew ? "Parent registered successfully." : "Parent updated successfully."
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    success = false,
                    message = ex.Message
                });
            }
        }

        [HttpDelete("DeleteParent/{id}")]
        public IActionResult DeleteParent(Guid id)
        {
            try
            {
                _repository.DeleteRecord("Parents", "ParentID", id);
                return Ok(new { success = true, message = "Parent deleted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    success = false,
                    message = ex.Message
                });
            }
        }

        // ==========================================
        // CHILD
        // ==========================================

        [HttpGet("GetChildrenByParent/{parentId}")]
        public IActionResult GetChildrenByParent(Guid parentId)
        {
            return Ok(_repository.GetChildrenByParent(parentId));
        }

        [HttpPost("SaveChild")]
        public IActionResult SaveChild([FromBody] Child child)
        {
            if (child == null)
                return BadRequest();

            bool success = _repository.SaveChild(child);

            return Ok(new
            {
                success,
                message = success ? "Child added successfully." : "Failed to add child."
            });
        }

        // ==========================================
        // INVENTORY
        // ==========================================

        [HttpGet("GetInventory")]
        public IActionResult GetInventory()
        {
            return Ok(_repository.GetVaccineStock());
        }

        // ==========================================
        // ROOMS
        // ==========================================

        [HttpGet("GetRooms")]
        public IActionResult GetRooms()
        {
            return Ok(_repository.GetRooms());
        }

        [HttpPost("AssignRoom")]
        public IActionResult AssignRoom([FromBody] AssignRoomModel model)
        {
            if (model == null)
                return BadRequest();

            return Ok(new
            {
                success = _repository.AssignRoom(model.QueueId, model.RoomId)
            });
        }

        [HttpPost("CompleteSession/{id}")]
        public IActionResult CompleteSession(Guid id)
        {
            return Ok(new
            {
                success = _repository.CompleteSession(id)
            });
        }
    }
}