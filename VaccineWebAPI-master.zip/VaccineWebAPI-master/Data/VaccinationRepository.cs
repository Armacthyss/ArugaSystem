﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using VaccineWebAPI.Models;

namespace VaccineWebAPI.Data
{
    public class VaccinationRepository
    {
        private readonly string _connectionString;

        public VaccinationRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // ============================================================
        // PARENT / GUARDIAN LOGIC
        // ============================================================
        public List<Parent> GetAllParents()
        {
            var list = new List<Parent>();
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand("SELECT ParentID, FirstName, MiddleName, LastName, Email, ContactNo, BarangayNo, Address FROM Parents ORDER BY LastName ASC", conn))
            {
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Parent
                        {
                            ParentID = reader.GetGuid(reader.GetOrdinal("ParentID")),
                            GivenName = reader["FirstName"].ToString(),
                            MiddleName = reader["MiddleName"]?.ToString(),
                            LastName = reader["LastName"].ToString(),
                            Email = reader["Email"].ToString(),
                            ContactNo = reader["ContactNo"].ToString(),
                            BarangayNo = reader["BarangayNo"]?.ToString(), // Fixed Name
                            Address = reader["Address"]?.ToString()        // Fixed Name
                        });
                    }
                }
            }
            return list;
        }

        public bool SaveParent(Parent p)
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand("Parent_SaveParent", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ParentID", p.ParentID == Guid.Empty ? DBNull.Value : p.ParentID);
                    cmd.Parameters.AddWithValue("@FirstName", p.GivenName);
                    cmd.Parameters.AddWithValue("@MiddleName", p.MiddleName);
                    cmd.Parameters.AddWithValue("@LastName", p.LastName);
                    cmd.Parameters.AddWithValue("@Email", p.Email);
                    cmd.Parameters.AddWithValue("@ContactNo", p.ContactNo);
                    cmd.Parameters.AddWithValue("@BarangayNo", p.BarangayNo);
                    cmd.Parameters.AddWithValue("@Address", p.Address);
                    cmd.Parameters.AddWithValue("@Password", p.Password); // Now passed to DB
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch { return false; }
        }
        // ============================================================
        // CHILD LOGIC
        // ============================================================

        public List<Child> GetChildrenByParent(Guid parentId)
        {
            var list = new List<Child>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(@"
                SELECT ChildID, ParentID, FirstName, LastName, BirthDate, PlaceOfBirth
                FROM Children
                WHERE ParentID = @ParentID", conn))
            {
                cmd.Parameters.AddWithValue("@ParentID", parentId);

                conn.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Child
                        {
                            ChildId = reader.GetGuid(reader.GetOrdinal("ChildID")),
                            ParentId = reader.GetGuid(reader.GetOrdinal("ParentID")),
                            FirstName = reader["FirstName"]?.ToString() ?? "",
                            LastName = reader["LastName"]?.ToString() ?? "",
                            BirthDate = reader.GetDateTime(reader.GetOrdinal("BirthDate")),
                            PlaceOfBirth = reader["PlaceOfBirth"] == DBNull.Value ? "" : reader["PlaceOfBirth"].ToString()
                        });
                    }
                }
            }

            return list;
        }

        public bool SaveChild(Child child)
        {

            Console.WriteLine(child.ParentId);
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand(@"
                    INSERT INTO Children
                    (ChildID, ParentID, FirstName, LastName, BirthDate, PlaceOfBirth)
                    VALUES
                    (NEWID(), @ParentID, @FirstName, @LastName, @BirthDate, @PlaceOfBirth)", conn))
                {
                    cmd.Parameters.AddWithValue("@ParentID", child.ParentId);
                    cmd.Parameters.AddWithValue("@FirstName", child.FirstName ?? "");
                    cmd.Parameters.AddWithValue("@LastName", child.LastName ?? "");
                    cmd.Parameters.AddWithValue("@BirthDate", child.BirthDate);
                    cmd.Parameters.AddWithValue("@PlaceOfBirth", child.PlaceOfBirth ?? "");

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("SaveChild Error: " + ex.Message);
                return false;
            }
        }

        // ============================================================
        // VACCINE INVENTORY
        // ============================================================

        public List<VaccineInventoryDto> GetVaccineStock()
        {
            var list = new List<VaccineInventoryDto>();

            string query = @"
                SELECT V.VaccineName, I.BatchID, I.ExpiryDate, I.QuantityRemaining
                FROM VaccineInventory I
                INNER JOIN Vaccines V ON I.VaccineID = V.VaccineID";

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(query, conn))
            {
                conn.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new VaccineInventoryDto
                        {
                            VaccineName = reader["VaccineName"]?.ToString() ?? "",
                            BatchId = reader.GetGuid(reader.GetOrdinal("BatchID")),
                            ExpiryDate = reader.GetDateTime(reader.GetOrdinal("ExpiryDate")),
                            Stock = reader.GetInt32(reader.GetOrdinal("QuantityRemaining"))
                        });
                    }
                }
            }

            return list;
        }

        // ============================================================
        // DELETE UTILITY (SAFE VERSION)
        // ============================================================

        public void DeleteRecord(string tableName, string pkColumn, Guid id)
        {
            // ⚠️ still basic version, but safer structure
            var allowedTables = new HashSet<string> { "Parents", "Children", "Vaccines" };

            if (!allowedTables.Contains(tableName))
                throw new Exception("Invalid table name");

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(
                $"DELETE FROM {tableName} WHERE {pkColumn} = @id", conn))
            {
                cmd.Parameters.AddWithValue("@id", id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // Dummy placeholders (your system logic)
        public object GetRooms() => new List<object>();
        public bool AssignRoom(Guid queueId, Guid roomId) => true;
        public bool CompleteSession(Guid roomId) => true;
    }
}