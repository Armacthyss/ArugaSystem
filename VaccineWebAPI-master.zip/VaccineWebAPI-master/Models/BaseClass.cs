﻿namespace VaccineWebAPI.Models
{
    public class BaseClass
    {
        public DateTime DateCreated { get; set; } = DateTime.Now;
        public string? UserCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public string? UserModified { get; set; }
        public bool IsDeleted { get; set; } = false;
    }
}