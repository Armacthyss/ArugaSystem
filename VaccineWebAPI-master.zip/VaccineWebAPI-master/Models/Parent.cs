namespace VaccineWebAPI.Models
{
    public class Parent
    {
        public Guid ParentID { get; set; }
        public string GivenName { get; set; } = string.Empty; // Maps to FirstName in DB
        public string MiddleName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string ContactNo { get; set; } = string.Empty;
        public string BarangayNo { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty; // Required for Save
    }
}
