namespace VaccineWebAPI.Models
{
    // Represents the Vaccine definition
    public class Vaccine
    {
        public int VaccineId { get; set; }
        public string VaccineName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }

    // Used for the inventory view in your repository
    public class VaccineInventoryDto
    {
        public string VaccineName { get; set; } = string.Empty;
        public Guid BatchId { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int Stock { get; set; }
    }
}