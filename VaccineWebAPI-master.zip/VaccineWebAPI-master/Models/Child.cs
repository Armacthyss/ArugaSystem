namespace VaccineWebAPI.Models
{
    public class Child : BaseClass
    {
        public Guid ChildId { get; set; }
        public Guid ParentId { get; set; } // Foreign Key
        public string FirstName { get; set; } = string.Empty;
        public string MiddleName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public DateTime BirthDate { get; set; }
        public string PlaceOfBirth { get; set; } = string.Empty;
    }
}