namespace VaccineWebAPI.Models
{
    public class User : BaseClass
    {
        public Guid UserID { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty; // Never store plain text passwords
        public string UserType { get; set; } = string.Empty; // Doctor, Nurse, etc.
        public string? PRCNo { get; set; }
        public string ContactNo { get; set; } = string.Empty;
    }
}