namespace VaccineWebAPI.Models
{
    public class AssignRoomModel
    {
        public Guid QueueId { get; set; }
        public Guid RoomId { get; set; }
    }
}