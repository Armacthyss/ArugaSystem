<template>
  <div class="flex h-screen bg-[#F8FAFC] font-sans antialiased text-slate-900">
    <AdminSideBar :navItems="navItems" />

    <div class="flex-1 flex flex-col overflow-hidden">
      <header class="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0">
        <div>
          <h2 class="font-bold text-[10px] tracking-widest text-slate-400 uppercase">Medical Operations</h2>
          <p class="text-lg font-bold text-slate-800">Vaccination Queue & Acceptance</p>
        </div>
        <div class="flex gap-3">
          <button @click="fetchData" class="p-2.5 text-slate-400 hover:text-emerald-600 transition-colors bg-slate-50 rounded-lg border border-slate-200">
            <RefreshCw class="w-4 h-4" :class="{'animate-spin': isLoading}" />
          </button>
          <button @click="showAddModal = true" class="bg-emerald-600 text-white px-5 py-2.5 rounded-lg text-xs font-bold hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-sm active:scale-95">
            <Plus class="w-4 h-4" /> ADD TO QUEUE
          </button> 
        </div>
      </header>

      <main class="flex-1 p-8 overflow-y-auto custom-scrollbar">
        <div class="max-w-400 mx-auto space-y-8">
          
          <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div v-for="station in activeStations" :key="station.roomId" 
                 class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between relative overflow-hidden transition-all"
                 :class="station.isOccupied ? 'border-orange-200 bg-orange-50/20' : 'border-emerald-200 bg-emerald-50/20'">
              <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center transition-colors" 
                     :class="station.isOccupied ? 'bg-orange-100 text-orange-600' : 'bg-emerald-100 text-emerald-600'">
                  <UserRound v-if="station.isOccupied" class="w-5 h-5 animate-pulse" />
                  <Stethoscope v-else class="w-5 h-5" />
                </div>
                <div>
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-tight">{{ station.roomName }}</p>
                  <p class="text-sm font-bold text-slate-800">{{ station.doctorName }}</p>
                </div>
              </div>
              <button v-if="station.isOccupied" @click="completeSession(station)" 
                      class="text-[9px] font-black uppercase px-2 py-1 rounded-md bg-orange-200 text-orange-700 hover:bg-emerald-600 hover:text-white transition-all">
                Mark Done
              </button>
              <span v-else class="text-[9px] font-black uppercase px-2 py-1 rounded-md bg-emerald-100 text-emerald-700">Ready</span>
            </div>
          </div>

          <div class="grid grid-cols-12 gap-8 items-start">
            
            <section class="col-span-12 lg:col-span-8 space-y-4">
              <div class="flex items-center justify-between px-1">
                <h3 class="font-bold text-slate-800 flex items-center gap-2">
                  <RefreshCw class="w-4 h-4 text-emerald-600" /> Waiting for Acceptance
                </h3>
              </div>

              <div class="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                <table class="w-full text-left">
                  <thead class="bg-slate-50/50 border-b border-slate-200">
                    <tr>
                      <th class="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Patient / Barangay</th>
                      <th class="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Required Vaccines</th>
                      <th class="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Assign Doctor</th>
                      <th class="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Handoff</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100">
                    <tr v-for="q in activeQueue" :key="q.id">
                      <td class="px-6 py-5">
                        <p class="text-sm font-bold text-slate-700">{{ q.firstName }} {{ q.lastName }}</p>
                        <p class="text-[10px] font-black text-emerald-600 uppercase tracking-tighter">Brgy. {{ q.barangayNo }}</p>
                      </td>
                      <td class="px-6 py-5">
                        <div class="flex flex-wrap gap-1">
                          <span v-for="vax in q.vaccines" :key="vax" class="text-[9px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                            {{ vax }}
                          </span>
                        </div>
                      </td>
                      <td class="px-6 py-5">
                        <select v-model="q.assignedStationId" 
                          class="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg px-3 py-2 outline-none focus:border-emerald-500">
                          <option value="">-- Choose Doctor --</option>
                          <option v-for="s in activeStations" :key="s.roomId" :value="s.roomId" :disabled="s.isOccupied">
                            {{ s.doctorName }} ({{ s.roomName }}) {{ s.isOccupied ? '— BUSY' : '' }}
                          </option>
                        </select>
                      </td>
                      <td class="px-6 py-5 text-right">
                        <button :disabled="!q.assignedStationId" @click="sendToRoom(q)"
                          class="bg-emerald-600 text-white px-4 py-2 rounded-xl text-[10px] font-bold hover:bg-emerald-700 disabled:opacity-20 uppercase transition-all active:scale-95 shadow-sm">
                          Accept
                        </button>
                      </td>
                    </tr>
                    <tr v-if="activeQueue.length === 0">
                      <td colspan="4" class="px-6 py-12 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">No patients in queue</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div class="mt-12 space-y-4">
                <h3 class="font-bold text-slate-800 flex items-center gap-2">
                  <Syringe class="w-4 h-4 text-emerald-600" /> Successfully Vaccinated (Today)
                </h3>
                <div class="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                  <table class="w-full text-left">
                    <thead class="bg-slate-50/30 border-b border-slate-200">
                      <tr>
                        <th class="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase">Patient</th>
                        <th class="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase">Barangay</th>
                        <th class="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase">Administered By</th>
                        <th class="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase text-right">Time Done</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                      <tr v-for="v in vaccinatedToday" :key="v.id" class="group hover:bg-emerald-50/30 transition-colors">
                        <td class="px-6 py-4">
                          <p class="text-xs font-bold text-slate-700">{{ v.firstName }} {{ v.lastName }}</p>
                          <div class="flex gap-1 mt-1">
                            <span v-for="vx in v.vaccines" :key="vx" class="text-[8px] font-bold text-emerald-600 border border-emerald-100 px-1 rounded">{{ vx }}</span>
                          </div>
                        </td>
                        <td class="px-6 py-4">
                          <p class="text-xs font-black text-slate-400 uppercase">Brgy. {{ v.barangayNo }}</p>
                        </td>
                        <td class="px-6 py-4">
                          <p class="text-xs text-slate-600 font-medium">{{ v.doctorName }}</p>
                        </td>
                        <td class="px-6 py-4 text-right">
                          <p class="text-[10px] font-bold text-emerald-600">{{ v.doneTime }}</p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </section>

            <section class="col-span-12 lg:col-span-4 space-y-4">
              <h3 class="font-bold text-slate-800 flex items-center gap-2 px-1">
                <Calendar class="w-4 h-4 text-emerald-600" /> Today's Expected Patients
              </h3>
              <div class="space-y-3 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
                <div v-for="p in expectedPatients" :key="p.id" 
                  class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center group hover:border-emerald-200 transition-all">
                  <div>
                    <p class="font-bold text-slate-700 text-sm leading-tight">{{ p.firstName }} {{ p.lastName }}</p>
                    <p class="text-[9px] font-black text-slate-400 uppercase mt-1">Brgy. {{ p.barangayNo }}</p>
                  </div>
                  <button @click="markAsArrived(p)" 
                    class="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-lg text-[10px] font-black hover:bg-emerald-600 hover:text-white transition-colors">
                    Add to Queue
                  </button>
                </div>
              </div>
            </section>

          </div>
        </div>

      </main>
      <Transition name="fade">
  <div v-if="showAddModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
    <div class="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
      <div class="bg-slate-50 px-8 py-6 border-b border-slate-100 flex justify-between items-center">
        <div>
          <h3 class="text-lg font-bold text-slate-800">Manual Registration</h3>
          <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">New Patient Walk-In</p>
        </div>
        <button @click="showAddModal = false" class="text-slate-400 hover:text-slate-600 transition-colors">
          <X class="w-5 h-5" />
        </button>
      </div>

      <form @submit.prevent="submitWalkIn" class="p-8 space-y-5">
        <div class="grid grid-cols-2 gap-4">
          <div class="space-y-1.5">
            <label class="text-[10px] font-bold text-slate-500 uppercase px-1">Child First Name</label>
            <input v-model="walkInForm.firstName" required type="text" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 outline-none transition-all" placeholder="Enter first name">
          </div>
          <div class="space-y-1.5">
            <label class="text-[10px] font-bold text-slate-500 uppercase px-1">Last Name</label>
            <input v-model="walkInForm.lastName" required type="text" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 outline-none transition-all" placeholder="Enter last name">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
          <div class="space-y-1.5">
            <label class="text-[10px] font-bold text-slate-500 uppercase px-1">Birth Date</label>
            <input v-model="walkInForm.birthDate" required type="date" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:border-emerald-500 outline-none transition-all">
          </div>
          <div class="space-y-1.5">
            <label class="text-[10px] font-bold text-slate-500 uppercase px-1">Barangay No.</label>
            <input v-model="walkInForm.barangayNo" required type="text" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:border-emerald-500 outline-none transition-all" placeholder="e.g. 04">
          </div>
        </div>

        <div class="space-y-1.5">
          <label class="text-[10px] font-bold text-slate-500 uppercase px-1">Parent/Guardian Name</label>
          <input v-model="walkInForm.parentName" required type="text" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:border-emerald-500 outline-none transition-all" placeholder="Full name of parent">
        </div>

        <div class="space-y-1.5">
          <label class="text-[10px] font-bold text-slate-500 uppercase px-1">Contact Number</label>
          <input v-model="walkInForm.contactNo" required type="text" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:border-emerald-500 outline-none transition-all" placeholder="09xxxxxxxxx">
        </div>

        <div class="space-y-1.5">
          <label class="text-[10px] font-bold text-slate-500 uppercase px-1">Select Vaccine</label>
          <select v-model="walkInForm.vaccineID" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:border-emerald-500 outline-none transition-all">
            <option :value="null">-- Select Vaccine Type --</option>
            <option v-for="v in vaccineOptions" :key="v.id" :value="v.id">{{ v.name }}</option>
          </select>
        </div>

        <div class="pt-4 flex gap-3">
          <button type="button" @click="showAddModal = false" class="flex-1 px-6 py-3 border border-slate-200 text-slate-500 rounded-xl text-xs font-bold hover:bg-slate-50 transition-all">CANCEL</button>
          <button type="submit" class="flex-1 px-6 py-3 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-600/20 active:scale-95 transition-all">ADD TO QUEUE</button>
        </div>
      </form>
    </div>
  </div>
</Transition>
    </div>
  </div>
</template>
<script setup>
import AdminSideBar from '@/assets/component/AdminSideBar.vue'
import { ref } from 'vue'
import {
  LayoutDashboard,
  Users,
  UserRound,
  Stethoscope,
  Syringe,
  Calendar,
  RefreshCw,
  Plus,
  FileText,
  X
} from 'lucide-vue-next'

/* =========================
   SIDEBAR NAVIGATION
========================= */
const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/AdminHome' },
  { id: 'parent', label: 'Parent', icon: Users, path: '/StaffParent' },
  { id: 'records', label: 'Children Record', icon: UserRound, path: '/StaffChild' },
  { id: 'staff', label: 'Doctor / Staff', icon: Stethoscope, path: '/StaffDocNurse' },
  { id: 'vaccines', label: 'Vaccines', icon: Syringe, path: '/StaffVaccine' },
  { id: 'calendar', label: 'Calendar', icon: Calendar, path: '/StaffCalendar' },
  { id: 'reports', label: 'Reports', icon: FileText, path: '/StaffReport' }
]

/* =========================
   LOADING
========================= */
const isLoading = ref(false)
const showAddModal = ref(false)

/* =========================
   DOCTOR ROOMS / STATIONS
========================= */
const activeStations = ref([
  {
    roomId: 1,
    roomName: 'Room 1',
    doctorName: 'Dr. Maria Santos',
    isOccupied: false
  },
  {
    roomId: 2,
    roomName: 'Room 2',
    doctorName: 'Dr. John Cruz',
    isOccupied: true
  },
  {
    roomId: 3,
    roomName: 'Room 3',
    doctorName: 'Dr. Angela Reyes',
    isOccupied: false
  },
  {
    roomId: 4,
    roomName: 'Room 4',
    doctorName: 'Dr. Michael Tan',
    isOccupied: true
  }
])

/* =========================
   ACTIVE QUEUE
========================= */
const activeQueue = ref([
  {
    id: 1,
    firstName: 'Sophia',
    lastName: 'Garcia',
    barangayNo: '01',
    vaccines: ['BCG', 'Hepatitis B'],
    assignedStationId: ''
  },
  {
    id: 2,
    firstName: 'Ethan',
    lastName: 'Lopez',
    barangayNo: '05',
    vaccines: ['OPV', 'DPT'],
    assignedStationId: ''
  },
  {
    id: 3,
    firstName: 'Olivia',
    lastName: 'Ramos',
    barangayNo: '08',
    vaccines: ['MMR'],
    assignedStationId: ''
  }
])

/* =========================
   EXPECTED PATIENTS
========================= */
const expectedPatients = ref([
  {
    id: 101,
    firstName: 'Lucas',
    lastName: 'Mendoza',
    barangayNo: '03'
  },
  {
    id: 102,
    firstName: 'Emma',
    lastName: 'Villanueva',
    barangayNo: '07'
  },
  {
    id: 103,
    firstName: 'Noah',
    lastName: 'Torres',
    barangayNo: '11'
  }
])

/* =========================
   VACCINATED TODAY
========================= */
const vaccinatedToday = ref([
  {
    id: 201,
    firstName: 'Mia',
    lastName: 'Fernandez',
    barangayNo: '02',
    doctorName: 'Dr. Maria Santos',
    vaccines: ['Pentavalent', 'OPV'],
    doneTime: '9:45 AM'
  },
  {
    id: 202,
    firstName: 'James',
    lastName: 'Aquino',
    barangayNo: '09',
    doctorName: 'Dr. John Cruz',
    vaccines: ['MMR'],
    doneTime: '10:15 AM'
  }
])

/* =========================
   VACCINE OPTIONS
========================= */
const vaccineOptions = ref([
  { id: 1, name: 'BCG' },
  { id: 2, name: 'Hepatitis B' },
  { id: 3, name: 'OPV (Polio)' },
  { id: 4, name: 'DPT' },
  { id: 5, name: 'MMR' },
  { id: 6, name: 'Pentavalent' }
])

/* =========================
   WALK-IN FORM
========================= */
const walkInForm = ref({
  firstName: '',
  lastName: '',
  birthDate: '',
  barangayNo: '',
  parentName: '',
  contactNo: '',
  vaccineID: null
})

/* =========================
   FUNCTIONS
========================= */

// Fake refresh
const fetchData = () => {
  isLoading.value = true

  setTimeout(() => {
    isLoading.value = false
  }, 1000)
}

// Move expected patient to queue
const markAsArrived = (p) => {
  activeQueue.value.push({
    ...p,
    vaccines: ['BCG'],
    assignedStationId: ''
  })

  expectedPatients.value = expectedPatients.value.filter(
    x => x.id !== p.id
  )
}

// Assign patient to doctor room
const sendToRoom = (patient) => {
  if (!patient.assignedStationId) return

  const station = activeStations.value.find(
    s => s.roomId === patient.assignedStationId
  )

  if (station) {
    station.isOccupied = true
  }

  activeQueue.value = activeQueue.value.filter(
    q => q.id !== patient.id
  )
}

// Complete vaccination
const completeSession = (station) => {
  station.isOccupied = false

  vaccinatedToday.value.unshift({
    id: Date.now(),
    firstName: 'New',
    lastName: 'Patient',
    barangayNo: '04',
    doctorName: station.doctorName,
    vaccines: ['OPV', 'MMR'],
    doneTime: new Date().toLocaleTimeString()
  })
}

// Manual walk-in submit
const submitWalkIn = () => {
  activeQueue.value.push({
    id: Date.now(),
    firstName: walkInForm.value.firstName,
    lastName: walkInForm.value.lastName,
    barangayNo: walkInForm.value.barangayNo,
    vaccines: [
      vaccineOptions.value.find(
        v => v.id === walkInForm.value.vaccineID
      )?.name || 'Unknown Vaccine'
    ],
    assignedStationId: ''
  })

  showAddModal.value = false

  walkInForm.value = {
    firstName: '',
    lastName: '',
    birthDate: '',
    barangayNo: '',
    parentName: '',
    contactNo: '',
    vaccineID: null
  }
}
</script>